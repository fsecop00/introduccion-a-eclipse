package es.unileon.prg.tema7;
/**
 * Clase con los ejercicios correspondientes a arrays de tipos basicos.
 *
 * @author PRG
 * @version 1.0
 */
public class Apartado030102 extends Apartado {

	@Override
	protected String obtenerPractica(){
		return "P-ARR";
	}

	@Override
	protected String obtenerBloque() {
		return "Arrays de tipos basicos";
	}

	/**
	 * Arrays de tipos basicos - Ejercicio1.
	 *
	 * Completar el metodo para crear y rellenar un vector de cien posiciones
	 * que contenga los primeros cien numeros pares. Una vez creada, se debera
	 * mostrar el contenido del vector por pantalla.
	 */
	public void ejercicio01() {
		cabecera("01", "Generar vector con los 100 primeros numeros pares");

		// Inicio modificacion
		int[] enteros =  new int[100];
		int dos=2;
		for(int i=0;i<100;i++){

			enteros[i]=dos;
			System.out.print(enteros[i]+" ");
			dos+=2;
		}


        // Fin modificacion
	}

	/**
	 * Arrays de tipos basicos - Ejercicio2.
	 *
	 * Dado el siguiente fragmento de codigo se pide:
	 *
	 * <ul>
	 * <li> Compilar y ejecutar el metodo
	 * <li> Analizar los resultados obtenidos
	 * <li> Explicar en el fichero LEEME.TXT el porque de los resultados
	 * <li> Modificar el odigo a fin de evitar la excepcion producida
	 * </ul>
	 */
	public void ejercicio02() {
		cabecera("02","Mostrar vector por pantalla");

		// Inicio modificacion
		int[] arrayEnteros = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9 };
		System.out.print(" { ");
		for(int i=0 ; i < arrayEnteros.length ; i++) {
			System.out.print(" "+arrayEnteros[i]+",");
		}
		System.out.println(" } ");
        // Fin modificacion
	}

	/**
	 * Arrays de tipos basicos - Ejercicio3.
	 *
	 * Completar el metodo para crear una matriz que contenga la tabla de
	 * multiplicar del numero 8. Una vez creada, se debera mostrar el
	 * contenido del vector por pantalla.
	 */
	public void ejercicio03() {
		cabecera("03", "Tabla de multiplicar del ocho");

		// Inicio modificacio
		int [][] m = new int[3][10];
		for(int i=0;i<10;i++)
		{
			m[0][i]=i+1;
		}
		for(int i=0;i<10;i++)
		{
			m[1][i]=8;
		}
		for(int i=0;i<10;i++)
		{
			m[2][i]=m[0][i]*m[1][i];
		}


		for(int i = 0;i< 3; i++){
			for(int j=0;j<10;j++)
			{
				System.out.print("["+m[i][j]+"]");

			}
			System.out.println();

		}
        // Fin modificacion
	}

	/**
	 * Arrays de tipos basicos - Ejercicio4.
	 *
	 * Se pide completar el metodo para mostrar por pantalla el tablero
	 * indicado en el enunciado de la practica.
	 */
	public void ejercicio04() {
		cabecera("04", "BonoLotoADA");

		// Inicio modificacion
		int[][] bonoloto =  new int [5][10];
		int value=0;
		int count=0;

		for(int i=0;i<5;i++){
			for(int j=0;j<10;j++){
					bonoloto[i][j]= value;
					value++;
			}
		}
		while(count!=3){
		for(int i=0;i<5;i++){
			for(int j=0;j<10;j++){
				System.out.print("["+bonoloto[i][j]+"]");
			}
			System.out.println();
		}
		count++;
		}
		// Fin modificacion

	}
}
